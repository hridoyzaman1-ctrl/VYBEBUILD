'use client';

import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useTheme } from 'next-themes';

const navItems = [
  { label: 'About', href: '#about' },
  { label: 'Programs', href: '#programs' },
  { label: 'Services', href: '#services' },
  { label: 'Approach', href: '#approach' },
  { label: 'Stories', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
];

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('');
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      const sections = navItems.map((item) => item.href.substring(1));
      for (const section of sections.reverse()) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 150) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
          isScrolled
            ? isDark 
              ? 'bg-black/90 backdrop-blur-md border-b border-neutral-900'
              : 'bg-white/90 backdrop-blur-md border-b border-purple-100 shadow-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-[1600px] mx-auto px-6 lg:px-12">
          <div className="flex items-center justify-between h-20 lg:h-24">
            {/* Logo */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="relative z-10 group flex items-center gap-3"
            >
              <div className={`w-10 h-10 border flex items-center justify-center transition-colors duration-500 ${
                isDark 
                  ? 'border-neutral-800 group-hover:border-white/40' 
                  : 'border-purple-200 group-hover:border-purple-400 bg-gradient-to-br from-purple-50 to-pink-50'
              }`}>
                <span className={`text-sm font-semibold tracking-tight ${isDark ? 'text-white' : 'text-purple-600'}`}>A</span>
              </div>
              <div className="hidden sm:block">
                <span className={`text-sm font-medium tracking-wide ${isDark ? 'text-white' : 'text-gray-800'}`}>AIM CENTRE</span>
                <span className={`text-sm font-light tracking-wide ml-1 ${isDark ? 'text-neutral-600' : 'text-purple-400'}`}>360</span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-10">
              {navItems.map((item) => (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item.href)}
                  className={`relative text-[12px] tracking-[0.15em] uppercase transition-colors duration-300 ${
                    activeSection === item.href.substring(1)
                      ? isDark ? 'text-white' : 'text-purple-600'
                      : isDark ? 'text-neutral-500 hover:text-white' : 'text-gray-500 hover:text-purple-600'
                  }`}
                >
                  {item.label}
                  <span
                    className={`absolute -bottom-1 left-0 h-px transition-all duration-500 ${
                      isDark ? 'bg-white' : 'bg-purple-500'
                    } ${activeSection === item.href.substring(1) ? 'w-full' : 'w-0'}`}
                  />
                </button>
              ))}
              <div className={`ml-4 pl-4 border-l ${isDark ? 'border-neutral-800' : 'border-purple-200'}`}>
                <ThemeToggle />
              </div>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex items-center gap-4 lg:hidden">
              <ThemeToggle />
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={`relative z-10 p-2 -mr-2 ${isDark ? 'text-white' : 'text-gray-800'}`}
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 transition-all duration-700 lg:hidden ${
          isDark ? 'bg-black' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'
        } ${isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-6">
          {navItems.map((item, index) => (
            <button
              key={item.href}
              onClick={() => handleNavClick(item.href)}
              className={`text-2xl font-extralight tracking-wide uppercase transition-all duration-500 ${
                activeSection === item.href.substring(1)
                  ? isDark ? 'text-white' : 'text-purple-600'
                  : isDark ? 'text-neutral-600' : 'text-gray-400'
              }`}
              style={{
                transitionDelay: isMobileMenuOpen ? `${index * 50}ms` : '0ms',
                transform: isMobileMenuOpen ? 'translateY(0)' : 'translateY(20px)',
                opacity: isMobileMenuOpen ? 1 : 0,
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}