'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useTheme } from 'next-themes';
import { 
  Video, 
  FileText, 
  MessageCircle, 
  BarChart3, 
  Headphones, 
  Award,
  Smartphone,
  Globe2
} from 'lucide-react';

const services = [
  {
    icon: Video,
    title: 'Live Interactive Classes',
    description: 'Real-time sessions with expert educators. Ask questions, participate in discussions, and learn collaboratively with peers.',
  },
  {
    icon: FileText,
    title: 'Comprehensive Study Materials',
    description: 'Curated notes, video lectures, practice problems, and past papers available in both English and Bangla.',
  },
  {
    icon: MessageCircle,
    title: 'One-on-One Tutoring',
    description: 'Personalized attention from qualified tutors who understand individual learning needs and adapt their teaching style.',
  },
  {
    icon: BarChart3,
    title: 'Progress Analytics',
    description: 'Detailed insights into learning progress, strengths, areas for improvement, and personalized recommendations.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Round-the-clock assistance from our dedicated support team. Never feel stuck in your learning journey.',
  },
  {
    icon: Award,
    title: 'Recognized Certifications',
    description: 'Earn certificates upon course completion that are recognized by educational institutions and employers.',
  },
  {
    icon: Smartphone,
    title: 'Mobile Learning',
    description: 'Learn on-the-go with our mobile-optimized platform. Download content for offline access anywhere.',
  },
  {
    icon: Globe2,
    title: 'Global Community',
    description: 'Connect with learners worldwide. Participate in forums, study groups, and collaborative projects.',
  },
];

export function ServicesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePosition({ x, y });
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [handleMouseMove]);

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      id="services"
      ref={sectionRef}
      className={`relative py-32 md:py-40 px-6 lg:px-12 overflow-hidden ${
        isDark ? 'bg-black' : 'bg-gradient-to-b from-purple-50/50 to-white'
      }`}
    >
      {/* Animated Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Moving Grid */}
        <div 
          className={`absolute inset-0 ${isDark ? 'opacity-[0.02]' : 'opacity-[0.4]'}`}
          style={{
            backgroundImage: isDark 
              ? `radial-gradient(circle at center, white 1px, transparent 1px)`
              : `radial-gradient(circle at center, rgba(147,112,219,0.2) 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
            transform: `translate(${mousePosition.x * 15}px, ${mousePosition.y * 15}px)`,
            transition: 'transform 0.4s ease-out',
          }}
        />
        
        {/* Light Mode Blobs */}
        {!isDark && mounted && (
          <>
            <div className="absolute top-40 left-20 w-96 h-96 bg-gradient-to-br from-blue-100/40 to-cyan-100/40 rounded-full blur-3xl" />
            <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-pink-100/40 to-purple-100/40 rounded-full blur-3xl" />
          </>
        )}
        
        {/* Dark Mode Floating Lines */}
        {isDark && (
          <>
            <div 
              className="absolute top-20 left-1/4 w-px h-40 bg-gradient-to-b from-transparent via-white/10 to-transparent"
              style={{
                transform: `translateY(${scrollY * 0.1}px)`,
              }}
            />
            <div 
              className="absolute bottom-40 right-1/3 w-px h-60 bg-gradient-to-b from-transparent via-white/10 to-transparent"
              style={{
                transform: `translateY(${-scrollY * 0.08}px)`,
              }}
            />
          </>
        )}
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <span
            className={`inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase mb-6 transition-all duration-700 ${
              isDark ? 'text-neutral-500' : 'text-purple-500'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          >
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
            What We Offer
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
          </span>
          <h2
            className={`text-4xl md:text-5xl lg:text-6xl font-extralight tracking-tight leading-[1.1] transition-all duration-700 ${
              isDark ? 'text-white' : 'text-gray-800'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
            style={{ 
              transitionDelay: '100ms',
              transform: isVisible ? `translateY(${mousePosition.y * -8}px)` : 'translateY(24px)',
            }}
          >
            Complete Learning
            <br />
            <span className={isDark ? 'text-neutral-500' : 'text-purple-400'}>Experience</span>
          </h2>
          <p
            className={`mt-6 text-base md:text-lg font-light leading-relaxed max-w-2xl mx-auto transition-all duration-700 ${
              isDark ? 'text-neutral-400' : 'text-gray-600'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
            style={{ transitionDelay: '200ms' }}
          >
            Everything you need to succeed in your educational journey, 
            all in one integrated platform designed with care.
          </p>
        </div>

        {/* Services Grid */}
        <div className={`grid md:grid-cols-2 lg:grid-cols-4 gap-px ${isDark ? 'bg-neutral-800' : 'bg-purple-100'}`}>
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
              style={{ transitionDelay: `${300 + index * 80}ms` }}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <div
                className={`relative p-8 md:p-10 h-full transition-all duration-500 cursor-default overflow-hidden group ${
                  isDark ? 'bg-black' : 'bg-white'
                }`}
              >
                {/* Hover Background Effect */}
                <div 
                  className={`absolute inset-0 transition-transform duration-500 origin-bottom ${
                    hoveredIndex === index ? 'scale-y-100' : 'scale-y-0'
                  } ${isDark ? 'bg-white' : 'bg-gradient-to-br from-purple-500 to-pink-500'}`}
                />
                
                {/* Content */}
                <div className="relative z-10">
                  <service.icon
                    className={`w-6 h-6 mb-6 transition-all duration-500 ${
                      hoveredIndex === index
                        ? isDark ? 'text-black transform -translate-y-1' : 'text-white transform -translate-y-1'
                        : isDark ? 'text-neutral-500' : 'text-purple-400'
                    }`}
                  />
                  <h3 
                    className={`text-lg font-light mb-3 transition-all duration-500 ${
                      hoveredIndex === index 
                        ? isDark ? 'text-black' : 'text-white'
                        : isDark ? 'text-white' : 'text-gray-800'
                    }`}
                  >
                    {service.title}
                  </h3>
                  <p
                    className={`text-sm leading-relaxed transition-all duration-500 ${
                      hoveredIndex === index 
                        ? isDark ? 'text-neutral-600' : 'text-white/80'
                        : isDark ? 'text-neutral-500' : 'text-gray-600'
                    }`}
                  >
                    {service.description}
                  </p>
                  
                  {/* Hover Indicator */}
                  <div 
                    className={`mt-6 flex items-center gap-2 text-xs tracking-wider uppercase transition-all duration-500 ${
                      hoveredIndex === index 
                        ? isDark ? 'opacity-100 translate-x-0 text-black' : 'opacity-100 translate-x-0 text-white'
                        : 'opacity-0 -translate-x-4'
                    }`}
                  >
                    <span>Learn More</span>
                    <span>→</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          className={`mt-20 text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{ transitionDelay: '900ms' }}
        >
          <p className={`mb-6 text-sm tracking-wide ${isDark ? 'text-neutral-500' : 'text-gray-500'}`}>
            Ready to transform your learning experience?
          </p>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className={`group relative px-10 py-4 text-xs tracking-[0.2em] uppercase overflow-hidden transition-all duration-500 ${
              isDark 
                ? 'bg-white text-black hover:bg-neutral-200' 
                : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 rounded-full shadow-lg shadow-purple-500/25'
            }`}
          >
            <span className="relative z-10">Start Learning Today</span>
          </button>
        </div>
      </div>
    </section>
  );
}