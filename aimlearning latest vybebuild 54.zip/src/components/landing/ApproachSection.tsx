'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useTheme } from 'next-themes';

const steps = [
  {
    number: '01',
    title: 'Assess',
    subtitle: 'Understand Your Needs',
    description:
      'Begin with a comprehensive assessment of current skills, learning style, goals, and any special requirements. We create a detailed learner profile to personalize your journey.',
  },
  {
    number: '02',
    title: 'Design',
    subtitle: 'Customize Your Path',
    description:
      'Based on your assessment, we design a tailored learning pathway. For special needs learners, this includes individualized education plans (IEPs) created with specialists.',
  },
  {
    number: '03',
    title: 'Engage',
    subtitle: 'Interactive Learning',
    description:
      'Dive into engaging content through live classes, interactive exercises, and collaborative projects. Our multi-sensory approach ensures effective learning for all types of learners.',
  },
  {
    number: '04',
    title: 'Support',
    subtitle: 'Continuous Care',
    description:
      'Throughout your journey, access mental health counselling, academic support, and wellness resources. Our team ensures you never feel alone in your educational pursuit.',
  },
  {
    number: '05',
    title: 'Achieve',
    subtitle: 'Celebrate Success',
    description:
      'Reach your goals with confidence. Earn certifications, build portfolios, and transition seamlessly to the next phase of your educational or career journey.',
  },
];

export function ApproachSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePosition({ x, y });
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [handleMouseMove]);

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      id="approach"
      ref={sectionRef}
      className={`relative py-32 md:py-40 px-6 lg:px-12 overflow-hidden ${
        isDark ? 'bg-[#0a0a0a]' : 'bg-white'
      }`}
    >
      {/* Animated Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Grid Pattern */}
        <div 
          className={`absolute inset-0 ${isDark ? 'opacity-[0.03]' : 'opacity-[0.3]'}`}
          style={{
            backgroundImage: isDark 
              ? `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`
              : `linear-gradient(rgba(147,112,219,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(147,112,219,0.1) 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
            transform: `translate(${mousePosition.x * 20}px, ${mousePosition.y * 20}px)`,
            transition: 'transform 0.3s ease-out',
          }}
        />
        
        {/* Light Mode Decorative Elements */}
        {!isDark && mounted && (
          <>
            <div className="absolute top-20 right-10 w-80 h-80 bg-gradient-to-br from-purple-100/50 to-pink-100/50 rounded-full blur-3xl" />
            <div className="absolute bottom-40 left-10 w-96 h-96 bg-gradient-to-br from-blue-100/40 to-cyan-100/40 rounded-full blur-3xl" />
          </>
        )}
        
        {/* Dark Mode Floating Shapes */}
        {isDark && (
          <>
            <div 
              className="absolute top-1/4 right-1/4 w-64 h-64 border border-white/5 rounded-full"
              style={{
                transform: `translate(${mousePosition.x * 40}px, ${mousePosition.y * 40}px) rotate(${scrollY * 0.02}deg)`,
                transition: 'transform 0.5s ease-out',
              }}
            />
            <div 
              className="absolute bottom-1/4 left-1/4 w-48 h-48 border border-white/5"
              style={{
                transform: `translate(${mousePosition.x * -30}px, ${mousePosition.y * -30}px) rotate(${45 + scrollY * 0.03}deg)`,
                transition: 'transform 0.5s ease-out',
              }}
            />
          </>
        )}
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        {/* Section Header */}
        <div className="mb-20 lg:mb-28">
          <span
            className={`inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase mb-6 transition-all duration-700 ${
              isDark ? 'text-neutral-500' : 'text-purple-500'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          >
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
            Our Approach
          </span>
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16">
            <h2
              className={`text-4xl md:text-5xl lg:text-6xl font-extralight tracking-tight leading-[1.1] transition-all duration-700 ${
                isDark ? 'text-white' : 'text-gray-800'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ 
                transitionDelay: '100ms',
                transform: isVisible ? `translateY(${mousePosition.y * -10}px)` : 'translateY(24px)',
              }}
            >
              The AIM
              <br />
              <span className={isDark ? 'text-neutral-500' : 'text-purple-400'}>Method</span>
            </h2>
            <p
              className={`text-base md:text-lg font-light leading-relaxed max-w-xl lg:ml-auto transition-all duration-700 ${
                isDark ? 'text-neutral-400' : 'text-gray-600'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ transitionDelay: '200ms' }}
            >
              Our proven five-step methodology ensures every learner receives personalized attention 
              and achieves their full potential through structured yet flexible education.
            </p>
          </div>
        </div>

        {/* Steps Navigation */}
        <div className="flex flex-wrap gap-2 mb-12">
          {steps.map((step, index) => (
            <button
              key={step.number}
              onClick={() => setActiveStep(index)}
              className={`px-4 py-2 text-xs tracking-wider uppercase border transition-all duration-500 ${
                activeStep === index
                  ? isDark 
                    ? 'bg-white text-black border-white' 
                    : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white border-purple-500 rounded-full'
                  : isDark 
                    ? 'bg-transparent text-neutral-400 border-neutral-800 hover:border-neutral-600 hover:text-white'
                    : 'bg-transparent text-gray-500 border-purple-200 hover:border-purple-400 hover:text-purple-600 rounded-full'
              }`}
            >
              {step.number} {step.title}
            </button>
          ))}
        </div>

        {/* Steps Content */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Visual Element */}
          <div 
            className={`relative h-[400px] md:h-[500px] flex items-center justify-center transition-all duration-700 ${
              isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
            style={{ transitionDelay: '300ms' }}
          >
            {/* Main Circle */}
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              {/* Outer Ring */}
              <div 
                className={`absolute inset-0 border rounded-full ${isDark ? 'border-white/10' : 'border-purple-200'}`}
                style={{
                  transform: `rotate(${scrollY * 0.05 + mousePosition.x * 20}deg)`,
                  transition: 'transform 0.3s ease-out',
                }}
              />
              
              {/* Middle Ring */}
              <div 
                className={`absolute inset-6 border rounded-full ${isDark ? 'border-white/10' : 'border-pink-200'}`}
                style={{
                  transform: `rotate(${-scrollY * 0.03 + mousePosition.y * 15}deg)`,
                  transition: 'transform 0.3s ease-out',
                }}
              />
              
              {/* Inner Ring */}
              <div 
                className={`absolute inset-12 border rounded-full ${isDark ? 'border-white/20' : 'border-purple-300'}`}
                style={{
                  transform: `rotate(${scrollY * 0.04}deg)`,
                  transition: 'transform 0.3s ease-out',
                }}
              />
              
              {/* Center Content */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <span 
                    className={`block text-6xl md:text-7xl font-extralight transition-all duration-500 ${
                      isDark ? 'text-white/20' : 'text-purple-200'
                    }`}
                    style={{
                      transform: `scale(${1 + mousePosition.x * 0.1})`,
                    }}
                  >
                    {steps[activeStep]?.number}
                  </span>
                </div>
              </div>
              
              {/* Orbiting Dots */}
              {[0, 1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className={`absolute w-2 h-2 rounded-full transition-all duration-700 ${
                    i === activeStep 
                      ? isDark ? 'bg-white' : 'bg-purple-500'
                      : isDark ? 'bg-white/20' : 'bg-purple-200'
                  }`}
                  style={{
                    top: '50%',
                    left: '50%',
                    transform: `rotate(${i * 72 + scrollY * 0.02}deg) translateX(${140 + (i === activeStep ? 10 : 0)}px) translateY(-50%)`,
                    transition: 'transform 0.5s ease-out, background-color 0.3s',
                  }}
                />
              ))}
            </div>
            
            {/* Floating Labels */}
            <div 
              className={`absolute top-10 left-10 text-[10px] tracking-[0.2em] uppercase ${
                isDark ? 'text-neutral-600' : 'text-purple-400'
              }`}
              style={{
                transform: `translate(${mousePosition.x * 30}px, ${mousePosition.y * 30}px)`,
                transition: 'transform 0.4s ease-out',
              }}
            >
              Personalized
            </div>
            <div 
              className={`absolute bottom-10 right-10 text-[10px] tracking-[0.2em] uppercase ${
                isDark ? 'text-neutral-600' : 'text-pink-400'
              }`}
              style={{
                transform: `translate(${mousePosition.x * -25}px, ${mousePosition.y * -25}px)`,
                transition: 'transform 0.4s ease-out',
              }}
            >
              Adaptive
            </div>
          </div>

          {/* Content */}
          <div>
            {steps.map((step, index) => (
              <div
                key={step.number}
                className={`transition-all duration-700 ${
                  activeStep === index
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-8 absolute pointer-events-none'
                }`}
              >
                <div className="flex items-baseline gap-4 mb-4">
                  <span className={`text-5xl md:text-6xl font-extralight ${isDark ? 'text-white/10' : 'text-purple-100'}`}>
                    {step.number}
                  </span>
                </div>
                <h3 className={`text-3xl md:text-4xl font-extralight mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                  {step.title}
                </h3>
                <p className={`text-sm mb-6 tracking-wide ${isDark ? 'text-neutral-500' : 'text-purple-500'}`}>
                  {step.subtitle}
                </p>
                <p className={`text-base md:text-lg leading-relaxed max-w-lg ${isDark ? 'text-neutral-400' : 'text-gray-600'}`}>
                  {step.description}
                </p>
                
                {/* Progress Bar */}
                <div className="mt-10 flex items-center gap-4">
                  <div className={`flex-1 h-px ${isDark ? 'bg-neutral-800' : 'bg-purple-100'}`}>
                    <div 
                      className={`h-full transition-all duration-700 ${isDark ? 'bg-white/40' : 'bg-gradient-to-r from-purple-500 to-pink-500'}`}
                      style={{ width: `${((index + 1) / steps.length) * 100}%` }}
                    />
                  </div>
                  <span className={`text-xs tracking-wider ${isDark ? 'text-neutral-500' : 'text-gray-400'}`}>
                    {index + 1} / {steps.length}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Features */}
        <div 
          className={`mt-24 lg:mt-32 grid md:grid-cols-3 gap-px border transition-all duration-700 ${
            isDark ? 'bg-neutral-800 border-neutral-800' : 'bg-purple-100 border-purple-100 rounded-xl overflow-hidden shadow-lg shadow-purple-100/50'
          } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          style={{ transitionDelay: '500ms' }}
        >
          {[
            { value: '95%', label: 'Success Rate', desc: 'Student achievement of goals' },
            { value: '24/7', label: 'Support', desc: 'Round-the-clock assistance' },
            { value: '100%', label: 'Personalized', desc: 'Tailored learning paths' },
          ].map((stat) => (
            <div 
              key={stat.label}
              className={`p-8 md:p-10 group cursor-default transition-all duration-500 ${
                isDark 
                  ? 'bg-[#0a0a0a] hover:bg-white' 
                  : 'bg-white hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500'
              }`}
            >
              <span className={`block text-3xl md:text-4xl font-extralight transition-colors duration-500 ${
                isDark 
                  ? 'text-white group-hover:text-black' 
                  : 'text-gray-800 group-hover:text-white'
              }`}>
                {stat.value}
              </span>
              <span className={`block text-sm mt-2 transition-colors duration-500 ${
                isDark 
                  ? 'text-white group-hover:text-black' 
                  : 'text-gray-800 group-hover:text-white'
              }`}>
                {stat.label}
              </span>
              <span className={`block text-xs mt-1 transition-colors duration-500 ${
                isDark 
                  ? 'text-neutral-500 group-hover:text-neutral-600' 
                  : 'text-gray-500 group-hover:text-white/80'
              }`}>
                {stat.desc}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}