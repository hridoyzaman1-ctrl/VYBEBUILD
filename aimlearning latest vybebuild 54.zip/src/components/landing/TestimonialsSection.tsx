'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { useTheme } from 'next-themes';

const testimonials = [
  {
    id: 1,
    quote:
      'AIM Centre 360 transformed my daughter\'s learning experience. As a child with ADHD, she struggled in traditional classrooms. The personalized approach and patient educators here have helped her flourish academically and build confidence.',
    name: 'Fatima Rahman',
    role: 'Parent',
    location: 'Dhaka, Bangladesh',
  },
  {
    id: 2,
    quote:
      'The bilingual courses were exactly what I needed. Being able to learn complex subjects in Bangla first, then transition to English helped me truly understand the material. I scored A* in my O-Levels!',
    name: 'Arif Hossain',
    role: 'O-Level Student',
    location: 'Chittagong, Bangladesh',
  },
  {
    id: 3,
    quote:
      'The mental health counselling services integrated into the platform made all the difference during my board exams. Having someone to talk to about stress and anxiety helped me perform my best.',
    name: 'Priya Sharma',
    role: 'HSC Graduate',
    location: 'Sylhet, Bangladesh',
  },
  {
    id: 4,
    quote:
      'As an educator, I\'ve seen many platforms, but AIM Centre 360\'s approach to special needs education is exceptional. The training and resources provided help us truly make a difference in children\'s lives.',
    name: 'Dr. Kamal Ahmed',
    role: 'Special Education Specialist',
    location: 'Rajshahi, Bangladesh',
  },
  {
    id: 5,
    quote:
      'From failing my first IELTS attempt to scoring 8.0, AIM Centre 360\'s test prep program gave me the strategies and confidence I needed. Now I\'m studying at my dream university in Canada!',
    name: 'Nusrat Jahan',
    role: 'University Student',
    location: 'Toronto, Canada',
  },
];

const stats = [
  { value: '98%', label: 'Student Satisfaction' },
  { value: '45%', label: 'Average Grade Improvement' },
  { value: '15K+', label: 'Success Stories' },
];

export function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width - 0.5,
      y: (e.clientY - rect.top) / rect.height - 0.5,
    });
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [handleMouseMove]);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const goToPrev = () => {
    setIsAutoPlaying(false);
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToNext = () => {
    setIsAutoPlaying(false);
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      id="testimonials"
      ref={sectionRef}
      className={`relative py-32 md:py-40 px-6 lg:px-12 overflow-hidden ${
        isDark ? 'bg-black' : 'bg-gradient-to-b from-white to-purple-50/50'
      }`}
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div 
          className={`absolute inset-0 ${isDark ? 'opacity-[0.015]' : 'opacity-[0.3]'}`}
          style={{
            backgroundImage: isDark 
              ? `linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)`
              : `linear-gradient(rgba(147,112,219,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(147,112,219,0.1) 1px, transparent 1px)`,
            backgroundSize: '80px 80px',
            transform: `translate(${mousePos.x * 15}px, ${mousePos.y * 15}px)`,
            transition: 'transform 0.5s ease-out',
          }}
        />
        
        {/* Light Mode Blobs */}
        {!isDark && mounted && (
          <>
            <div className="absolute top-20 left-10 w-80 h-80 bg-gradient-to-br from-pink-100/50 to-purple-100/50 rounded-full blur-3xl" />
            <div className="absolute bottom-40 right-20 w-96 h-96 bg-gradient-to-br from-blue-100/40 to-cyan-100/40 rounded-full blur-3xl" />
          </>
        )}
        
        {/* Decorative Quote */}
        <div 
          className={`absolute top-1/4 left-10 text-[200px] font-serif select-none ${
            isDark ? 'text-white/[0.01]' : 'text-purple-100'
          }`}
          style={{
            transform: `translate(${mousePos.x * 30}px, ${mousePos.y * 30}px)`,
            transition: 'transform 0.6s ease-out',
          }}
        >
          &ldquo;
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <span
            className={`inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase mb-6 transition-all duration-700 ${
              isDark ? 'text-neutral-600' : 'text-purple-500'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          >
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
            Success Stories
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
          </span>
          <h2
            className={`text-4xl md:text-5xl lg:text-6xl font-extralight tracking-tight leading-[1.1] transition-all duration-700 ${
              isDark ? 'text-white' : 'text-gray-800'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
            style={{ 
              transitionDelay: '100ms',
              transform: isVisible ? `translateY(${mousePos.y * -8}px)` : 'translateY(24px)',
            }}
          >
            Voices of
            <br />
            <span className={isDark ? 'text-neutral-600' : 'text-purple-400'}>Achievement</span>
          </h2>
        </div>

        {/* Testimonial Carousel */}
        <div
          className={`relative max-w-4xl mx-auto mb-20 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{ transitionDelay: '200ms' }}
        >
          <Quote className={`absolute -top-8 left-0 w-16 h-16 ${isDark ? 'text-white/[0.03]' : 'text-purple-200'}`} />

          <div className="relative min-h-[350px] md:min-h-[280px]">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className={`absolute inset-0 transition-all duration-700 ${
                  index === activeIndex
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-6 pointer-events-none'
                }`}
              >
                <blockquote 
                  className={`text-xl md:text-2xl lg:text-3xl font-extralight leading-relaxed ${
                    isDark ? 'text-white/90' : 'text-gray-700'
                  }`}
                  style={{
                    transform: `translateY(${mousePos.y * -10}px)`,
                    transition: 'transform 0.5s ease-out',
                  }}
                >
                  &ldquo;{testimonial.quote}&rdquo;
                </blockquote>
                <div className="mt-10 flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center text-lg font-light ${
                    isDark 
                      ? 'bg-neutral-900 border border-neutral-800 text-white' 
                      : 'bg-gradient-to-br from-purple-400 to-pink-400 text-white'
                  }`}>
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className={`text-base font-light ${isDark ? 'text-white' : 'text-gray-800'}`}>{testimonial.name}</p>
                    <p className={`text-sm ${isDark ? 'text-neutral-600' : 'text-gray-500'}`}>
                      {testimonial.role} · {testimonial.location}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-12">
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setIsAutoPlaying(false);
                    setActiveIndex(index);
                  }}
                  className={`h-px transition-all duration-500 ${
                    index === activeIndex
                      ? isDark ? 'w-10 bg-white' : 'w-10 bg-purple-500'
                      : isDark ? 'w-6 bg-white/20 hover:bg-white/40' : 'w-6 bg-purple-200 hover:bg-purple-400'
                  }`}
                />
              ))}
            </div>

            <div className="flex gap-2">
              <button
                onClick={goToPrev}
                className={`w-10 h-10 border flex items-center justify-center transition-all duration-300 ${
                  isDark 
                    ? 'border-neutral-800 text-white hover:border-white/40 hover:bg-white hover:text-black' 
                    : 'border-purple-200 text-purple-600 hover:border-purple-400 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white rounded-full'
                }`}
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={goToNext}
                className={`w-10 h-10 border flex items-center justify-center transition-all duration-300 ${
                  isDark 
                    ? 'border-neutral-800 text-white hover:border-white/40 hover:bg-white hover:text-black' 
                    : 'border-purple-200 text-purple-600 hover:border-purple-400 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white rounded-full'
                }`}
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div
          className={`grid md:grid-cols-3 gap-px transition-all duration-700 ${
            isDark ? 'bg-neutral-900' : 'bg-purple-100 rounded-xl overflow-hidden shadow-lg shadow-purple-100/50'
          } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          style={{ transitionDelay: '400ms' }}
        >
          {stats.map((stat) => (
            <div
              key={stat.label}
              className={`p-10 md:p-14 text-center group cursor-default transition-all duration-500 ${
                isDark 
                  ? 'bg-black hover:bg-white' 
                  : 'bg-white hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500'
              }`}
            >
              <div className={`text-4xl md:text-5xl lg:text-6xl font-extralight mb-3 transition-all duration-500 group-hover:scale-105 ${
                isDark 
                  ? 'text-white group-hover:text-black' 
                  : 'text-gray-800 group-hover:text-white'
              }`}>
                {stat.value}
              </div>
              <div className={`text-[10px] tracking-[0.2em] uppercase transition-colors duration-500 ${
                isDark 
                  ? 'text-neutral-600 group-hover:text-neutral-500' 
                  : 'text-gray-500 group-hover:text-white/80'
              }`}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}