"use client";

import { 
  Sparkles, Zap, Globe, Shield, Clock, 
  BarChart3, Headphones, Award, Rocket
} from "lucide-react";
import { useEffect, useRef, useState } from "react";

const features = [
  {
    icon: Sparkles,
    title: "AI-Powered Learning",
    description: "Personalized learning paths that adapt to your pace, style, and goals in real-time.",
    gradient: "from-violet-500 to-purple-500",
  },
  {
    icon: Globe,
    title: "Learn Anywhere",
    description: "Access courses on any device, anytime. Seamless sync across all your platforms.",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Zap,
    title: "Interactive Labs",
    description: "Hands-on practice with real-world projects and live coding environments.",
    gradient: "from-orange-500 to-amber-500",
  },
  {
    icon: Shield,
    title: "Verified Certificates",
    description: "Industry-recognized credentials that boost your professional profile.",
    gradient: "from-emerald-500 to-teal-500",
  },
  {
    icon: Clock,
    title: "Flexible Schedule",
    description: "Learn at your own pace with lifetime access to all enrolled courses.",
    gradient: "from-pink-500 to-rose-500",
  },
  {
    icon: BarChart3,
    title: "Progress Analytics",
    description: "Track your growth with detailed insights and skill assessments.",
    gradient: "from-indigo-500 to-blue-500",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "Get help anytime with AI tutors and community mentors always available.",
    gradient: "from-red-500 to-orange-500",
  },
  {
    icon: Award,
    title: "Career Services",
    description: "Resume reviews, interview prep, and direct connections to top employers.",
    gradient: "from-cyan-500 to-teal-500",
  },
];

function FeatureCard({ feature, index, isVisible, scrollProgress }: {
  feature: typeof features[0];
  index: number;
  isVisible: boolean;
  scrollProgress: number;
}) {
  const [isHovered, setIsHovered] = useState(false);
  const row = Math.floor(index / 4);
  const parallaxOffset = row % 2 === 0 ? scrollProgress * 20 : scrollProgress * -20;

  return (
    <div
      className={`group relative transition-all duration-700 ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
      style={{
        transitionDelay: `${index * 100}ms`,
        transform: isVisible 
          ? `translateY(0) translateX(${parallaxOffset}px)` 
          : "translateY(40px)",
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`relative h-full p-6 rounded-3xl glass border border-transparent hover:border-primary/30 transition-all duration-500 ${isHovered ? 'glow-primary' : ''}`}>
        {/* Gradient Background on Hover */}
        <div className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
        
        {/* Icon Container */}
        <div 
          className={`relative w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-5 transition-all duration-500 ${
            isHovered ? "scale-110 rotate-6" : ""
          }`}
        >
          <feature.icon className="w-7 h-7 text-white" />
          
          {/* Glow Effect */}
          <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-500`} />
        </div>

        {/* Content */}
        <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
          {feature.title}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {feature.description}
        </p>

        {/* Decorative Corner */}
        <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden rounded-tr-3xl">
          <div className={`absolute -top-10 -right-10 w-20 h-20 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rotate-45`} />
        </div>
      </div>
    </div>
  );
}

export function FeaturesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry && entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        const windowHeight = window.innerHeight;
        const sectionCenter = rect.top + rect.height / 2;
        const progress = 1 - sectionCenter / windowHeight;
        setScrollProgress(Math.max(-1, Math.min(1, progress)));
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section
      ref={sectionRef}
      id="features"
      className="relative py-32 overflow-hidden bg-muted/30"
    >
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div 
          className="absolute top-1/4 left-0 w-1/2 h-1/2 bg-primary/5 rounded-full blur-3xl"
          style={{ transform: `translateX(${scrollProgress * -50}px)` }}
        />
        <div 
          className="absolute bottom-1/4 right-0 w-1/2 h-1/2 bg-accent/5 rounded-full blur-3xl"
          style={{ transform: `translateX(${scrollProgress * 50}px)` }}
        />
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(124,58,237,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(124,58,237,0.02)_1px,transparent_1px)] bg-[size:40px_40px]" />

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-16">
          <div
            className={`max-w-2xl transition-all duration-1000 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
              Platform Features
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Everything You Need to <span className="text-gradient">Excel</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Our platform is packed with powerful features designed to make your 
              learning journey effective, engaging, and enjoyable.
            </p>
          </div>

          {/* Floating Element */}
          <div
            className={`relative transition-all duration-1000 delay-300 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <div className="glass rounded-2xl p-6 animate-float">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <Rocket className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-2xl font-bold">360°</div>
                  <div className="text-sm text-muted-foreground">Complete Learning</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              feature={feature}
              index={index}
              isVisible={isVisible}
              scrollProgress={scrollProgress}
            />
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          className={`mt-20 text-center transition-all duration-1000 delay-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full glass border border-primary/20">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-sm">
              <span className="text-primary font-semibold">New:</span> AI Study Assistant now available in all courses
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
