'use client';

import { useEffect, useState } from 'react';
import { ArrowUp, Facebook, Instagram, Linkedin, Youtube, Twitter } from 'lucide-react';
import { toast } from 'sonner';
import { useTheme } from 'next-themes';

const footerLinks = {
  programs: [
    { label: 'English Medium', href: '#programs' },
    { label: 'Bangla Version', href: '#programs' },
    { label: 'Special Needs Education', href: '#programs' },
    { label: 'Mental Health Support', href: '#programs' },
    { label: 'Skill Development', href: '#programs' },
    { label: 'Test Preparation', href: '#programs' },
  ],
  company: [
    { label: 'About Us', href: '#about' },
    { label: 'Our Approach', href: '#approach' },
    { label: 'Success Stories', href: '#testimonials' },
    { label: 'Careers', href: '#' },
    { label: 'Blog', href: '#' },
  ],
  support: [
    { label: 'Help Center', href: '#' },
    { label: 'Contact Us', href: '#contact' },
    { label: 'FAQs', href: '#' },
    { label: 'Parent Resources', href: '#' },
    { label: 'Student Portal', href: '#' },
  ],
  legal: [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
    { label: 'Refund Policy', href: '#' },
    { label: 'Cookie Policy', href: '#' },
  ],
};

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Youtube, href: '#', label: 'YouTube' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Twitter, href: '#', label: 'Twitter' },
];

export function Footer() {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [email, setEmail] = useState('');
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('Subscribed successfully!', {
        description: 'Thank you for joining our newsletter.',
      });
      setEmail('');
    }
  };

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <footer className={`relative border-t py-20 md:py-28 px-6 lg:px-12 ${
      isDark ? 'border-neutral-900 bg-black' : 'border-purple-100 bg-white'
    }`}>
      <div className="max-w-[1600px] mx-auto">
        {/* Newsletter Section */}
        <div className={`grid lg:grid-cols-2 gap-12 pb-16 mb-16 border-b ${isDark ? 'border-neutral-900' : 'border-purple-100'}`}>
          <div>
            <h3 className={`text-2xl md:text-3xl font-extralight mb-4 ${isDark ? 'text-white' : 'text-gray-800'}`}>
              Stay Updated
            </h3>
            <p className={`text-sm max-w-md leading-relaxed ${isDark ? 'text-neutral-500' : 'text-gray-600'}`}>
              Subscribe to our newsletter for educational insights, tips, and updates
              on new programs and features.
            </p>
          </div>
          <form onSubmit={handleNewsletterSubmit} className="flex gap-4 items-end">
            <div className="flex-1">
              <label className={`text-[10px] tracking-[0.2em] uppercase mb-2 block ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className={`w-full bg-transparent border-b py-3 text-base font-light focus:outline-none transition-colors ${
                  isDark 
                    ? 'border-neutral-800 text-white focus:border-white/60 placeholder:text-neutral-700' 
                    : 'border-purple-200 text-gray-800 focus:border-purple-500 placeholder:text-gray-400'
                }`}
              />
            </div>
            <button
              type="submit"
              className={`px-8 py-3 text-xs tracking-[0.15em] uppercase transition-all duration-500 whitespace-nowrap ${
                isDark 
                  ? 'bg-white text-black hover:bg-neutral-200' 
                  : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 rounded-full'
              }`}
            >
              Subscribe
            </button>
          </form>
        </div>

        {/* Main Footer Content */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-10 mb-16">
          {/* Brand */}
          <div className="col-span-2 md:col-span-3 lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 border flex items-center justify-center ${
                  isDark ? 'border-neutral-800' : 'border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg'
                }`}>
                  <span className={`text-sm font-semibold ${isDark ? 'text-white' : 'text-purple-600'}`}>A</span>
                </div>
                <div>
                  <span className={`text-sm font-medium tracking-wide ${isDark ? 'text-white' : 'text-gray-800'}`}>AIM CENTRE</span>
                  <span className={`text-sm font-light tracking-wide ml-1 ${isDark ? 'text-neutral-600' : 'text-purple-400'}`}>360</span>
                </div>
              </div>
              <p className={`text-[10px] tracking-[0.2em] uppercase ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                Aim High, Achieve Infinity
              </p>
            </div>
            <p className={`text-sm leading-relaxed max-w-xs mb-8 ${isDark ? 'text-neutral-500' : 'text-gray-600'}`}>
              Empowering learners across Bangladesh and beyond with inclusive, 
              accessible, and transformative education for all.
            </p>
            {/* Social Links */}
            <div className="flex gap-2">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className={`w-10 h-10 border flex items-center justify-center transition-all duration-500 ${
                    isDark 
                      ? 'border-neutral-800 text-neutral-600 hover:border-white/30 hover:bg-white hover:text-black' 
                      : 'border-purple-200 text-purple-400 hover:border-purple-400 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white rounded-lg'
                  }`}
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Programs */}
          <div>
            <h4 className={`text-[10px] tracking-[0.2em] uppercase mb-6 ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
              Programs
            </h4>
            <ul className="space-y-3">
              {footerLinks.programs.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className={`text-sm transition-colors duration-300 ${
                      isDark ? 'text-neutral-500 hover:text-white' : 'text-gray-500 hover:text-purple-600'
                    }`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className={`text-[10px] tracking-[0.2em] uppercase mb-6 ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
              Company
            </h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className={`text-sm transition-colors duration-300 ${
                      isDark ? 'text-neutral-500 hover:text-white' : 'text-gray-500 hover:text-purple-600'
                    }`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className={`text-[10px] tracking-[0.2em] uppercase mb-6 ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
              Support
            </h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className={`text-sm transition-colors duration-300 ${
                      isDark ? 'text-neutral-500 hover:text-white' : 'text-gray-500 hover:text-purple-600'
                    }`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className={`text-[10px] tracking-[0.2em] uppercase mb-6 ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
              Legal
            </h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className={`text-sm transition-colors duration-300 ${
                      isDark ? 'text-neutral-500 hover:text-white' : 'text-gray-500 hover:text-purple-600'
                    }`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className={`flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t ${
          isDark ? 'border-neutral-900' : 'border-purple-100'
        }`}>
          <p className={`text-xs ${isDark ? 'text-neutral-600' : 'text-gray-500'}`}>
            © {new Date().getFullYear()} AIM Centre 360. All rights reserved.
          </p>
          <p className={`text-xs ${isDark ? 'text-neutral-600' : 'text-gray-500'}`}>
            Made with ❤️ in Bangladesh
          </p>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-8 right-8 w-12 h-12 border flex items-center justify-center transition-all duration-500 z-50 ${
          isDark 
            ? 'border-neutral-800 bg-black text-white hover:border-white/40 hover:bg-white hover:text-black' 
            : 'border-purple-200 bg-white text-purple-600 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white hover:border-purple-500 rounded-full shadow-lg shadow-purple-200/50'
        } ${showScrollTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
}