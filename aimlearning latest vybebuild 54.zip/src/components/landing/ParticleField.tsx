'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useTheme } from 'next-themes';

interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  baseOpacity: number;
}

interface Line {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  progress: number;
  speed: number;
  opacity: number;
}

export function ParticleField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const particlesRef = useRef<Particle[]>([]);
  const linesRef = useRef<Line[]>([]);
  const animationRef = useRef<number>(0);
  const scrollRef = useRef(0);
  const { resolvedTheme } = useTheme();

  const initParticles = useCallback((width: number, height: number) => {
    const particles: Particle[] = [];
    const count = Math.min(120, Math.floor((width * height) / 12000));

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        z: Math.random() * 800,
        vx: (Math.random() - 0.5) * 0.15,
        vy: (Math.random() - 0.5) * 0.15,
        vz: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 1.5 + 0.5,
        baseOpacity: Math.random() * 0.3 + 0.1,
      });
    }
    return particles;
  }, []);

  const initLines = useCallback((width: number, height: number) => {
    const lines: Line[] = [];
    const lineCount = 8;

    for (let i = 0; i < lineCount; i++) {
      const isHorizontal = Math.random() > 0.5;
      lines.push({
        startX: isHorizontal ? 0 : Math.random() * width,
        startY: isHorizontal ? Math.random() * height : 0,
        endX: isHorizontal ? width : Math.random() * width,
        endY: isHorizontal ? Math.random() * height : height,
        progress: Math.random(),
        speed: 0.0005 + Math.random() * 0.001,
        opacity: 0.05 + Math.random() * 0.1,
      });
    }
    return lines;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(dpr, dpr);
      particlesRef.current = initParticles(window.innerWidth, window.innerHeight);
      linesRef.current = initLines(window.innerWidth, window.innerHeight);
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.targetX = (e.clientX / window.innerWidth - 0.5) * 2;
      mouseRef.current.targetY = (e.clientY / window.innerHeight - 0.5) * 2;
    };

    const handleScroll = () => {
      scrollRef.current = window.scrollY;
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);

    const animate = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const particles = particlesRef.current;
      const lines = linesRef.current;
      const mouse = mouseRef.current;
      const isDark = resolvedTheme === 'dark';
      const color = isDark ? '255, 255, 255' : '0, 0, 0';

      // Smooth mouse interpolation
      mouse.x += (mouse.targetX - mouse.x) * 0.03;
      mouse.y += (mouse.targetY - mouse.y) * 0.03;

      // Clear canvas
      ctx.clearRect(0, 0, width, height);

      // Draw animated lines
      lines.forEach((line) => {
        line.progress += line.speed;
        if (line.progress > 1) line.progress = 0;

        const currentX = line.startX + (line.endX - line.startX) * line.progress;
        const currentY = line.startY + (line.endY - line.startY) * line.progress;

        // Draw trailing line
        const gradient = ctx.createLinearGradient(
          line.startX,
          line.startY,
          currentX,
          currentY
        );
        gradient.addColorStop(0, `rgba(${color}, 0)`);
        gradient.addColorStop(0.8, `rgba(${color}, ${line.opacity * 0.5})`);
        gradient.addColorStop(1, `rgba(${color}, ${line.opacity})`);

        ctx.beginPath();
        ctx.moveTo(line.startX, line.startY);
        ctx.lineTo(currentX, currentY);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Draw glowing point at the end
        ctx.beginPath();
        ctx.arc(currentX, currentY, 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${color}, ${line.opacity * 2})`;
        ctx.fill();
      });

      // Update and draw particles
      particles.forEach((p, i) => {
        // Mouse influence with depth
        const mouseInfluenceX = mouse.x * 25;
        const mouseInfluenceY = mouse.y * 25;

        // Scroll parallax
        const scrollOffset = scrollRef.current * 0.05;
        const depthFactor = (800 - p.z) / 800;

        // Update position
        p.x += p.vx + mouseInfluenceX * depthFactor * 0.015;
        p.y += p.vy + mouseInfluenceY * depthFactor * 0.015;
        p.z += p.vz;

        // Wrap around edges
        if (p.x < -50) p.x = width + 50;
        if (p.x > width + 50) p.x = -50;
        if (p.y < -50) p.y = height + 50;
        if (p.y > height + 50) p.y = -50;
        if (p.z < 0) p.z = 800;
        if (p.z > 800) p.z = 0;

        // Perspective projection
        const perspective = 600;
        const scale = perspective / (perspective + p.z);
        const screenX = width / 2 + (p.x - width / 2) * scale;
        const screenY = height / 2 + (p.y - height / 2 - scrollOffset * depthFactor) * scale;
        const screenSize = p.size * scale;

        // Draw particle
        const opacity = p.baseOpacity * scale * 1.5;
        ctx.beginPath();
        ctx.arc(screenX, screenY, screenSize, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${color}, ${opacity})`;
        ctx.fill();

        // Draw connections to nearby particles
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          if (!p2) continue;
          
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dz = p.z - p2.z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

          if (dist < 120) {
            const scale2 = perspective / (perspective + p2.z);
            const screenX2 = width / 2 + (p2.x - width / 2) * scale2;
            const screenY2 = height / 2 + (p2.y - height / 2 - scrollOffset * ((800 - p2.z) / 800)) * scale2;
            const lineOpacity = (1 - dist / 120) * 0.08 * scale * scale2;

            ctx.beginPath();
            ctx.moveTo(screenX, screenY);
            ctx.lineTo(screenX2, screenY2);
            ctx.strokeStyle = `rgba(${color}, ${lineOpacity})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      cancelAnimationFrame(animationRef.current);
    };
  }, [initParticles, initLines, resolvedTheme]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
