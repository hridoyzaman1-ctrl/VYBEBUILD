'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { toast } from 'sonner';
import { ArrowRight, Mail, MapPin, Phone, Clock } from 'lucide-react';
import { useTheme } from 'next-themes';

export function ContactSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    program: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width - 0.5,
      y: (e.clientY - rect.top) / rect.height - 0.5,
    });
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [handleMouseMove]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise((resolve) => setTimeout(resolve, 1500));

    toast.success('Message sent successfully!', {
      description: 'Our team will contact you within 24 hours.',
    });

    setFormData({ name: '', email: '', phone: '', program: '', message: '' });
    setIsSubmitting(false);
  };

  const contactInfo = [
    { icon: Mail, label: 'Email', value: 'hello@aimcentre360.com', href: 'mailto:hello@aimcentre360.com' },
    { icon: Phone, label: 'Phone', value: '+880 1XXX-XXXXXX', href: 'tel:+8801XXXXXXXXX' },
    { icon: MapPin, label: 'Location', value: 'Dhaka, Bangladesh', href: '#' },
    { icon: Clock, label: 'Hours', value: 'Sat-Thu: 9AM - 9PM', href: '#' },
  ];

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      id="contact"
      ref={sectionRef}
      className={`relative py-32 md:py-40 px-6 lg:px-12 overflow-hidden ${
        isDark ? 'bg-[#050505]' : 'bg-gradient-to-b from-purple-50/50 to-white'
      }`}
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div 
          className={`absolute inset-0 ${isDark ? 'opacity-[0.02]' : 'opacity-[0.3]'}`}
          style={{
            backgroundImage: isDark 
              ? `radial-gradient(circle at center, white 1px, transparent 1px)`
              : `radial-gradient(circle at center, rgba(147,112,219,0.2) 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
            transform: `translate(${mousePos.x * 15}px, ${mousePos.y * 15}px)`,
            transition: 'transform 0.5s ease-out',
          }}
        />
        
        {/* Light Mode Blobs */}
        {!isDark && mounted && (
          <>
            <div className="absolute top-10 right-20 w-96 h-96 bg-gradient-to-br from-purple-100/50 to-pink-100/50 rounded-full blur-3xl" />
            <div className="absolute bottom-20 left-10 w-80 h-80 bg-gradient-to-br from-blue-100/40 to-cyan-100/40 rounded-full blur-3xl" />
          </>
        )}
        
        {/* Dark Mode Decorative Circle */}
        {isDark && (
          <div 
            className="absolute -right-40 top-1/3 w-[500px] h-[500px] rounded-full border border-white/[0.02]"
            style={{
              transform: `translate(${mousePos.x * -30}px, ${mousePos.y * -30}px)`,
              transition: 'transform 0.6s ease-out',
            }}
          />
        )}
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20 lg:mb-28">
          <span
            className={`inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase mb-6 transition-all duration-700 ${
              isDark ? 'text-neutral-600' : 'text-purple-500'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          >
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
            Get in Touch
            <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
          </span>
          <h2
            className={`text-4xl md:text-5xl lg:text-6xl font-extralight tracking-tight leading-[1.1] transition-all duration-700 ${
              isDark ? 'text-white' : 'text-gray-800'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
            style={{ transitionDelay: '100ms' }}
          >
            Start Your
            <br />
            <span className={isDark ? 'text-neutral-600' : 'text-purple-400'}>Journey Today</span>
          </h2>
          <p
            className={`mt-6 text-base md:text-lg font-light leading-relaxed max-w-2xl mx-auto transition-all duration-700 ${
              isDark ? 'text-neutral-500' : 'text-gray-600'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
            style={{ transitionDelay: '200ms' }}
          >
            Have questions about our programs? Ready to enroll? We're here to help
            you find the perfect learning path for your needs.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Contact Form */}
          <div
            className={`lg:col-span-3 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
            style={{ transitionDelay: '300ms' }}
          >
            <form onSubmit={handleSubmit} className={`p-8 md:p-12 ${
              isDark 
                ? 'bg-black border border-neutral-900' 
                : 'bg-white border border-purple-100 rounded-2xl shadow-xl shadow-purple-100/50'
            }`}>
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div className="space-y-2">
                  <label className={`text-[10px] tracking-[0.2em] uppercase ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={`w-full bg-transparent border-b py-3 text-base font-light focus:outline-none transition-colors ${
                      isDark 
                        ? 'border-neutral-800 text-white focus:border-white/60 placeholder:text-neutral-700' 
                        : 'border-purple-200 text-gray-800 focus:border-purple-500 placeholder:text-gray-400'
                    }`}
                    placeholder="Your full name"
                  />
                </div>
                <div className="space-y-2">
                  <label className={`text-[10px] tracking-[0.2em] uppercase ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`w-full bg-transparent border-b py-3 text-base font-light focus:outline-none transition-colors ${
                      isDark 
                        ? 'border-neutral-800 text-white focus:border-white/60 placeholder:text-neutral-700' 
                        : 'border-purple-200 text-gray-800 focus:border-purple-500 placeholder:text-gray-400'
                    }`}
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div className="space-y-2">
                  <label className={`text-[10px] tracking-[0.2em] uppercase ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={`w-full bg-transparent border-b py-3 text-base font-light focus:outline-none transition-colors ${
                      isDark 
                        ? 'border-neutral-800 text-white focus:border-white/60 placeholder:text-neutral-700' 
                        : 'border-purple-200 text-gray-800 focus:border-purple-500 placeholder:text-gray-400'
                    }`}
                    placeholder="+880 1XXX-XXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <label className={`text-[10px] tracking-[0.2em] uppercase ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                    Program of Interest
                  </label>
                  <select
                    value={formData.program}
                    onChange={(e) => setFormData({ ...formData, program: e.target.value })}
                    className={`w-full bg-transparent border-b py-3 text-base font-light focus:outline-none transition-colors appearance-none cursor-pointer ${
                      isDark 
                        ? 'border-neutral-800 text-white focus:border-white/60' 
                        : 'border-purple-200 text-gray-800 focus:border-purple-500'
                    }`}
                  >
                    <option value="" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>Select a program</option>
                    <option value="english-medium" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>English Medium</option>
                    <option value="bangla-version" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>Bangla Version</option>
                    <option value="special-needs" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>Special Needs Education</option>
                    <option value="mental-health" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>Mental Health Counselling</option>
                    <option value="skill-development" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>Skill Development</option>
                    <option value="test-prep" className={isDark ? 'bg-black text-white' : 'bg-white text-gray-800'}>Test Preparation</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2 mb-10">
                <label className={`text-[10px] tracking-[0.2em] uppercase ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                  Your Message
                </label>
                <textarea
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className={`w-full bg-transparent border-b py-3 text-base font-light focus:outline-none transition-colors resize-none ${
                    isDark 
                      ? 'border-neutral-800 text-white focus:border-white/60 placeholder:text-neutral-700' 
                      : 'border-purple-200 text-gray-800 focus:border-purple-500 placeholder:text-gray-400'
                  }`}
                  placeholder="Tell us about your learning goals, any special requirements, or questions you have..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={`group flex items-center gap-3 px-10 py-4 text-xs tracking-[0.2em] uppercase transition-all duration-500 hover:gap-5 disabled:opacity-50 ${
                  isDark 
                    ? 'bg-white text-black hover:bg-neutral-200' 
                    : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 rounded-full shadow-lg shadow-purple-500/25'
                }`}
              >
                <span>{isSubmitting ? 'Sending...' : 'Send Message'}</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div
            className={`lg:col-span-2 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
            style={{ transitionDelay: '400ms' }}
          >
            <div className="space-y-4">
              {contactInfo.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className={`flex items-start gap-5 p-6 group transition-all duration-500 ${
                    isDark 
                      ? 'bg-black border border-neutral-900 hover:border-white/20 hover:bg-white' 
                      : 'bg-white border border-purple-100 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 rounded-xl shadow-md shadow-purple-100/30'
                  }`}
                >
                  <div className={`w-12 h-12 border flex items-center justify-center flex-shrink-0 transition-colors duration-500 ${
                    isDark 
                      ? 'border-neutral-800 group-hover:border-black/20' 
                      : 'border-purple-200 group-hover:border-white/30 rounded-lg'
                  }`}>
                    <item.icon className={`w-5 h-5 transition-colors duration-500 ${
                      isDark 
                        ? 'text-neutral-600 group-hover:text-black' 
                        : 'text-purple-400 group-hover:text-white'
                    }`} />
                  </div>
                  <div>
                    <p className={`text-[10px] tracking-[0.2em] uppercase mb-1 transition-colors duration-500 ${
                      isDark 
                        ? 'text-neutral-600 group-hover:text-neutral-500' 
                        : 'text-gray-500 group-hover:text-white/70'
                    }`}>
                      {item.label}
                    </p>
                    <p className={`text-base font-light transition-colors duration-500 ${
                      isDark 
                        ? 'text-white group-hover:text-black' 
                        : 'text-gray-800 group-hover:text-white'
                    }`}>
                      {item.value}
                    </p>
                  </div>
                </a>
              ))}
            </div>

            {/* Additional Info Box */}
            <div className={`mt-6 p-8 transition-all duration-500 ${
              isDark 
                ? 'bg-black border border-neutral-900 group hover:bg-white hover:border-white' 
                : 'bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-100 rounded-xl'
            }`}>
              <h4 className={`text-[10px] tracking-[0.2em] uppercase mb-4 ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                Free Consultation
              </h4>
              <p className={`text-sm font-light leading-relaxed mb-6 ${isDark ? 'text-neutral-500' : 'text-gray-600'}`}>
                Not sure which program is right for you or your child? Book a free
                consultation with our education advisors. We'll help you find the perfect fit.
              </p>
              <button
                onClick={() => toast.info('Consultation booking coming soon!')}
                className={`text-xs tracking-[0.15em] uppercase hover:underline underline-offset-4 ${
                  isDark ? 'text-white' : 'text-purple-600'
                }`}
              >
                Book Free Consultation →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}