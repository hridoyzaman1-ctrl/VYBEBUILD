'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { ArrowRight, Clock, Users, Star } from 'lucide-react';
import { useTheme } from 'next-themes';

const programs = [
  {
    id: 'english-medium',
    title: 'English Medium',
    subtitle: 'Cambridge & Edexcel Curriculum',
    duration: 'Full Academic Year',
    level: 'All Levels',
    students: '15,000+',
    rating: '4.9',
    description:
      'Comprehensive English medium education following international curricula. From primary to A-Levels, our expert educators deliver world-class instruction aligned with Cambridge and Edexcel standards.',
    features: ['Live Interactive Classes', 'Practice Tests & Assessments', 'Personalized Feedback', 'Parent Progress Reports'],
  },
  {
    id: 'bangla-version',
    title: 'Bangla Version',
    subtitle: 'National Curriculum Bangladesh',
    duration: 'Full Academic Year',
    level: 'Class 1-12',
    students: '25,000+',
    rating: '4.8',
    description:
      'Complete Bangla medium education following the National Curriculum of Bangladesh. SSC, HSC, and all board exam preparations with native language instruction and comprehensive study materials.',
    features: ['Board Exam Preparation', 'Chapter-wise Video Lessons', 'Model Tests', 'Doubt Clearing Sessions'],
  },
  {
    id: 'special-needs',
    title: 'Special Needs Education',
    subtitle: 'Customized Learning Programs',
    duration: 'Flexible',
    level: 'Individualized',
    students: '2,000+',
    rating: '5.0',
    description:
      'Specially designed educational programs for children with autism, ADHD, dyslexia, and other learning differences. Each program is tailored to the individual child\'s needs, strengths, and learning pace.',
    features: ['One-on-One Sessions', 'Sensory-Friendly Content', 'Progress Tracking', 'Family Support Training'],
  },
  {
    id: 'mental-health',
    title: 'Mental Health & Counselling',
    subtitle: 'Student Wellness Programs',
    duration: 'Ongoing Support',
    level: 'All Ages',
    students: '5,000+',
    rating: '4.9',
    description:
      'Professional mental health support integrated into the learning journey. Licensed counsellors provide guidance for academic stress, anxiety, peer relationships, and personal development.',
    features: ['Confidential Sessions', 'Group Workshops', 'Crisis Support', 'Wellness Resources'],
  },
  {
    id: 'skill-development',
    title: 'Skill Development',
    subtitle: 'Future-Ready Skills',
    duration: '8-16 Weeks',
    level: 'Intermediate',
    students: '8,000+',
    rating: '4.7',
    description:
      'Practical skill courses in coding, digital literacy, creative arts, and communication. Prepare students for the modern workforce with industry-relevant certifications and hands-on projects.',
    features: ['Project-Based Learning', 'Industry Mentors', 'Certifications', 'Portfolio Building'],
  },
  {
    id: 'test-prep',
    title: 'Test Preparation',
    subtitle: 'IELTS, SAT, GRE & More',
    duration: '4-12 Weeks',
    level: 'Advanced',
    students: '10,000+',
    rating: '4.8',
    description:
      'Expert-led test preparation courses for international standardized exams. Proven strategies, extensive practice materials, and mock tests to maximize your scores.',
    features: ['Score Guarantee', 'Full-Length Mock Tests', 'Expert Strategies', 'Admission Guidance'],
  },
];

export function ProgramsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [activeProgram, setActiveProgram] = useState<string | null>('english-medium');
  const [hoveredProgram, setHoveredProgram] = useState<string | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePosition({ x, y });
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [handleMouseMove]);

  const currentProgram = programs.find((p) => p.id === (hoveredProgram || activeProgram));
  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      id="programs"
      ref={sectionRef}
      className={`relative py-32 md:py-40 px-6 lg:px-12 overflow-hidden ${
        isDark ? 'bg-[#050505]' : 'bg-white'
      }`}
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Subtle Grid */}
        <div 
          className={`absolute inset-0 ${isDark ? 'opacity-[0.015]' : 'opacity-[0.3]'}`}
          style={{
            backgroundImage: isDark 
              ? `linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)`
              : `linear-gradient(rgba(147,112,219,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(147,112,219,0.15) 1px, transparent 1px)`,
            backgroundSize: '80px 80px',
            transform: `translate(${mousePosition.x * 10}px, ${mousePosition.y * 10}px)`,
            transition: 'transform 0.5s ease-out',
          }}
        />
        
        {/* Light Mode Decorative Blobs */}
        {!isDark && mounted && (
          <>
            <div className="absolute top-20 right-20 w-80 h-80 bg-gradient-to-br from-pink-100/50 to-purple-100/50 rounded-full blur-3xl" />
            <div className="absolute bottom-20 left-20 w-96 h-96 bg-gradient-to-br from-blue-100/40 to-cyan-100/40 rounded-full blur-3xl" />
          </>
        )}
        
        {/* Decorative Line */}
        <div 
          className={`absolute left-6 lg:left-12 top-0 bottom-0 w-px ${isDark ? 'bg-neutral-900' : 'bg-purple-100'}`}
          style={{
            transform: `scaleY(${isVisible ? 1 : 0})`,
            transformOrigin: 'top',
            transition: 'transform 1s ease-out',
          }}
        />
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        {/* Section Header */}
        <div className="mb-16 lg:mb-24">
          <span
            className={`inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase mb-6 transition-all duration-700 ${
              isDark ? 'text-neutral-600' : 'text-purple-500'
            } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          >
            <span className={`w-6 h-px ${isDark ? 'bg-white/10' : 'bg-purple-300'}`} />
            Our Programs
          </span>
          <div className="grid lg:grid-cols-2 gap-8">
            <h2
              className={`text-4xl md:text-5xl lg:text-6xl font-extralight tracking-tight leading-[1.1] transition-all duration-700 ${
                isDark ? 'text-white' : 'text-gray-800'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ transitionDelay: '100ms' }}
            >
              Learning Paths
              <br />
              <span className={isDark ? 'text-neutral-600' : 'text-purple-400'}>For Everyone</span>
            </h2>
            <p
              className={`text-base md:text-lg font-light leading-relaxed max-w-xl lg:ml-auto lg:text-right transition-all duration-700 ${
                isDark ? 'text-neutral-500' : 'text-gray-600'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ transitionDelay: '200ms' }}
            >
              Discover comprehensive educational programs designed to meet diverse learning needs, 
              from traditional academics to specialized support services.
            </p>
          </div>
        </div>

        {/* Programs Grid */}
        <div className={`grid lg:grid-cols-2 gap-0 border ${
          isDark ? 'border-neutral-900' : 'border-purple-100'
        } ${!isDark ? 'rounded-2xl overflow-hidden shadow-xl shadow-purple-100/50' : ''}`}>
          {/* Program List */}
          <div className={`border-r ${isDark ? 'border-neutral-900' : 'border-purple-100'}`}>
            {programs.map((program, index) => (
              <div
                key={program.id}
                className={`transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-6'
                }`}
                style={{ transitionDelay: `${300 + index * 80}ms` }}
              >
                <button
                  onClick={() => setActiveProgram(program.id)}
                  onMouseEnter={() => setHoveredProgram(program.id)}
                  onMouseLeave={() => setHoveredProgram(null)}
                  className={`relative w-full text-left py-6 px-6 md:px-8 flex items-center justify-between group transition-all duration-500 border-b overflow-hidden ${
                    isDark ? 'border-neutral-900' : 'border-purple-100'
                  } ${
                    (hoveredProgram || activeProgram) === program.id
                      ? isDark ? 'text-black' : 'text-white'
                      : isDark ? 'text-white' : 'text-gray-800'
                  }`}
                >
                  {/* Background Fill Animation */}
                  <div 
                    className={`absolute inset-0 transition-transform duration-500 origin-left ${
                      (hoveredProgram || activeProgram) === program.id
                        ? 'scale-x-100'
                        : 'scale-x-0'
                    } ${isDark ? 'bg-white' : 'bg-gradient-to-r from-purple-500 to-pink-500'}`}
                  />
                  
                  {/* Content */}
                  <div className="relative z-10 flex-1">
                    <h3 className="text-lg md:text-xl font-light">{program.title}</h3>
                    <p
                      className={`text-xs md:text-sm mt-1 transition-colors duration-500 ${
                        (hoveredProgram || activeProgram) === program.id
                          ? isDark ? 'text-neutral-600' : 'text-white/70'
                          : isDark ? 'text-neutral-600' : 'text-gray-500'
                      }`}
                    >
                      {program.subtitle}
                    </p>
                  </div>
                  <ArrowRight
                    className={`relative z-10 w-4 h-4 transition-all duration-500 ${
                      (hoveredProgram || activeProgram) === program.id
                        ? 'translate-x-0 opacity-100'
                        : '-translate-x-4 opacity-0'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>

          {/* Program Details */}
          <div className={`min-h-[500px] lg:min-h-0 ${isDark ? 'bg-[#080808]' : 'bg-gradient-to-br from-purple-50 to-pink-50'}`}>
            <div
              className={`p-8 md:p-12 lg:p-16 h-full transition-all duration-500 ${
                currentProgram ? 'opacity-100' : 'opacity-0'
              }`}
            >
              {currentProgram && (
                <>
                  {/* Meta Info */}
                  <div className="flex flex-wrap gap-3 mb-8">
                    <span className={`inline-flex items-center gap-2 text-xs tracking-wide uppercase px-3 py-1.5 border transition-all duration-300 ${
                      isDark 
                        ? 'border-neutral-800 text-neutral-400 hover:border-neutral-600 hover:text-white' 
                        : 'border-purple-200 text-purple-600 hover:border-purple-400 hover:bg-purple-100 rounded-full'
                    }`}>
                      <Clock className="w-3 h-3" />
                      {currentProgram.duration}
                    </span>
                    <span className={`inline-flex items-center gap-2 text-xs tracking-wide uppercase px-3 py-1.5 border transition-all duration-300 ${
                      isDark 
                        ? 'border-neutral-800 text-neutral-400 hover:border-neutral-600 hover:text-white' 
                        : 'border-pink-200 text-pink-600 hover:border-pink-400 hover:bg-pink-100 rounded-full'
                    }`}>
                      <Users className="w-3 h-3" />
                      {currentProgram.students}
                    </span>
                    <span className={`inline-flex items-center gap-2 text-xs tracking-wide uppercase px-3 py-1.5 border transition-all duration-300 ${
                      isDark 
                        ? 'border-neutral-800 text-neutral-400 hover:border-neutral-600 hover:text-white' 
                        : 'border-amber-200 text-amber-600 hover:border-amber-400 hover:bg-amber-100 rounded-full'
                    }`}>
                      <Star className="w-3 h-3" />
                      {currentProgram.rating}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h4 className={`text-2xl md:text-3xl font-extralight mb-2 ${isDark ? 'text-white' : 'text-gray-800'}`}>
                    {currentProgram.title}
                  </h4>
                  <p className={`text-sm mb-6 ${isDark ? 'text-neutral-600' : 'text-purple-500'}`}>
                    {currentProgram.level}
                  </p>
                  <p className={`text-base leading-relaxed mb-8 ${isDark ? 'text-neutral-400' : 'text-gray-600'}`}>
                    {currentProgram.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-3 mb-10">
                    {currentProgram.features.map((feature, index) => (
                      <div
                        key={index}
                        className={`flex items-center gap-3 text-sm transition-colors duration-300 cursor-default ${
                          isDark ? 'text-neutral-300 hover:text-white' : 'text-gray-600 hover:text-purple-600'
                        }`}
                      >
                        <span className={`w-1 h-1 rounded-full ${isDark ? 'bg-neutral-600' : 'bg-purple-400'}`} />
                        {feature}
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  <button className={`group flex items-center gap-3 text-xs tracking-[0.2em] uppercase transition-all duration-300 hover:gap-5 ${
                    isDark ? 'text-white' : 'text-purple-600'
                  }`}>
                    <span>Explore Program</span>
                    <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}