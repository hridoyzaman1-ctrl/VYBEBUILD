'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { Globe, Users, Heart, Brain, BookOpen, Sparkles } from 'lucide-react';
import { useTheme } from 'next-themes';

const features = [
  {
    icon: Globe,
    number: '01',
    title: 'Bilingual Excellence',
    description: 'Complete course offerings in both English and Bangla, ensuring accessible education for all learners regardless of language preference.',
  },
  {
    icon: Users,
    number: '02',
    title: 'Inclusive Learning',
    description: 'Specially designed programs for children with special needs, with customized learning paths tailored to individual capabilities and growth.',
  },
  {
    icon: Heart,
    number: '03',
    title: 'Mental Wellness',
    description: 'Integrated mental health counselling services supporting the holistic development of every learner throughout their educational journey.',
  },
  {
    icon: Brain,
    number: '04',
    title: 'Adaptive Technology',
    description: 'AI-powered learning systems that adapt to each student\'s pace, style, and needs for truly personalized education.',
  },
];

const highlights = [
  { icon: BookOpen, label: 'Expert-Led Courses', value: '200+' },
  { icon: Users, label: 'Certified Educators', value: '150+' },
  { icon: Sparkles, label: 'Learning Paths', value: '50+' },
];

export function AboutSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width - 0.5,
      y: (e.clientY - rect.top) / rect.height - 0.5,
    });
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [handleMouseMove]);

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      id="about"
      ref={sectionRef}
      className={`relative py-32 md:py-40 px-6 lg:px-12 overflow-hidden ${
        isDark ? 'bg-[#030303]' : 'bg-gradient-to-b from-white to-purple-50/50'
      }`}
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Animated Grid */}
        <div
          className={`absolute inset-0 ${isDark ? 'opacity-[0.02]' : 'opacity-[0.3]'}`}
          style={{
            backgroundImage: isDark 
              ? `radial-gradient(circle at center, white 1px, transparent 1px)`
              : `radial-gradient(circle at center, rgba(147,112,219,0.3) 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
            transform: `translate(${mousePos.x * 20}px, ${mousePos.y * 20}px)`,
            transition: 'transform 0.5s ease-out',
          }}
        />
        
        {/* Floating Circles - Light Mode Colorful */}
        {!isDark && mounted && (
          <>
            <div
              className="absolute w-96 h-96 rounded-full bg-gradient-to-br from-purple-100/60 to-pink-100/60 blur-3xl"
              style={{
                top: '5%',
                right: '-10%',
                transform: `translate(${mousePos.x * -40}px, ${mousePos.y * -40}px)`,
                transition: 'transform 0.8s ease-out',
              }}
            />
            <div
              className="absolute w-80 h-80 rounded-full bg-gradient-to-br from-blue-100/50 to-cyan-100/50 blur-3xl"
              style={{
                bottom: '10%',
                left: '-5%',
                transform: `translate(${mousePos.x * 30}px, ${mousePos.y * 30}px)`,
                transition: 'transform 0.6s ease-out',
              }}
            />
          </>
        )}
        
        {/* Dark Mode Circles */}
        {isDark && (
          <>
            <div
              className="absolute w-[500px] h-[500px] rounded-full border border-white/[0.02]"
              style={{
                top: '10%',
                right: '-15%',
                transform: `translate(${mousePos.x * -40}px, ${mousePos.y * -40}px) rotate(${scrollY * 0.01}deg)`,
                transition: 'transform 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            />
            <div
              className="absolute w-[300px] h-[300px] rounded-full border border-white/[0.03]"
              style={{
                bottom: '15%',
                left: '-8%',
                transform: `translate(${mousePos.x * 30}px, ${mousePos.y * 30}px)`,
                transition: 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            />
          </>
        )}
        
        {/* Vertical Lines */}
        <div 
          className={`absolute left-1/4 top-0 bottom-0 w-px ${isDark ? 'bg-white/[0.02]' : 'bg-purple-200/30'}`}
          style={{
            transform: `translateX(${mousePos.x * 15}px)`,
            transition: 'transform 0.5s ease-out',
          }}
        />
        <div 
          className={`absolute right-1/3 top-0 bottom-0 w-px ${isDark ? 'bg-white/[0.02]' : 'bg-pink-200/30'}`}
          style={{
            transform: `translateX(${mousePos.x * -10}px)`,
            transition: 'transform 0.5s ease-out',
          }}
        />
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        {/* Section Header */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-24 mb-24 lg:mb-32">
          <div>
            <span
              className={`inline-flex items-center gap-3 text-[11px] tracking-[0.3em] uppercase mb-6 transition-all duration-700 ${
                isDark ? 'text-neutral-600' : 'text-purple-500'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
            >
              <span className={`w-6 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
              About Us
            </span>
            <h2
              className={`text-4xl md:text-5xl lg:text-6xl font-extralight tracking-tight leading-[1.1] transition-all duration-700 ${
                isDark ? 'text-white' : 'text-gray-800'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ 
                transitionDelay: '100ms',
                transform: isVisible ? `translateY(${mousePos.y * -8}px)` : 'translateY(24px)',
              }}
            >
              Education Without
              <br />
              <span className={isDark ? 'text-neutral-600' : 'text-purple-400'}>Boundaries</span>
            </h2>
          </div>
          <div
            className={`flex items-end transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            <p className={`text-base md:text-lg font-light leading-[1.8] max-w-xl ${
              isDark ? 'text-neutral-500' : 'text-gray-600'
            }`}>
              AIM Centre 360 is pioneering inclusive education in Bangladesh and beyond. 
              We believe every learner deserves access to world-class education, regardless of 
              their background, language, or learning needs. Our platform combines cutting-edge 
              technology with compassionate pedagogy to create transformative learning experiences.
            </p>
          </div>
        </div>

        {/* Highlights Bar */}
        <div
          className={`grid grid-cols-3 gap-px mb-24 lg:mb-32 transition-all duration-700 ${
            isDark ? 'bg-neutral-900' : 'bg-purple-100'
          } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          style={{ transitionDelay: '300ms' }}
        >
          {highlights.map((item) => (
            <div
              key={item.label}
              className={`p-6 md:p-10 flex flex-col md:flex-row items-center justify-center gap-4 text-center md:text-left group cursor-default transition-all duration-500 ${
                isDark 
                  ? 'bg-[#030303] hover:bg-white' 
                  : 'bg-white hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500'
              }`}
            >
              <item.icon className={`w-5 h-5 transition-colors duration-500 ${
                isDark 
                  ? 'text-neutral-600 group-hover:text-black' 
                  : 'text-purple-400 group-hover:text-white'
              }`} />
              <div>
                <div className={`text-2xl md:text-3xl font-extralight transition-colors duration-500 ${
                  isDark 
                    ? 'text-white group-hover:text-black' 
                    : 'text-gray-800 group-hover:text-white'
                }`}>
                  {item.value}
                </div>
                <div className={`text-[10px] md:text-xs tracking-[0.15em] uppercase transition-colors duration-500 ${
                  isDark 
                    ? 'text-neutral-600 group-hover:text-neutral-500' 
                    : 'text-gray-500 group-hover:text-white/80'
                }`}>
                  {item.label}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Features Grid */}
        <div className={`grid md:grid-cols-2 gap-px ${isDark ? 'bg-neutral-900' : 'bg-purple-100'}`}>
          {features.map((feature, index) => (
            <div
              key={feature.number}
              className={`relative p-8 md:p-12 lg:p-16 overflow-hidden transition-all duration-700 ${
                isDark ? 'bg-[#030303]' : 'bg-white'
              } ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ transitionDelay: `${400 + index * 100}ms` }}
              onMouseEnter={() => setHoveredFeature(index)}
              onMouseLeave={() => setHoveredFeature(null)}
            >
              {/* Hover Background */}
              <div 
                className={`absolute inset-0 transition-transform duration-700 origin-bottom ${
                  hoveredFeature === index ? 'scale-y-100' : 'scale-y-0'
                } ${isDark ? 'bg-white' : 'bg-gradient-to-br from-purple-500 to-pink-500'}`}
              />
              
              {/* Content */}
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-8">
                  <span 
                    className={`text-6xl md:text-7xl font-extralight transition-colors duration-500 ${
                      hoveredFeature === index 
                        ? isDark ? 'text-black/10' : 'text-white/20'
                        : isDark ? 'text-white/[0.04]' : 'text-purple-100'
                    }`}
                  >
                    {feature.number}
                  </span>
                  <feature.icon 
                    className={`w-6 h-6 transition-all duration-500 ${
                      hoveredFeature === index 
                        ? isDark ? 'text-black transform -translate-y-1' : 'text-white transform -translate-y-1'
                        : isDark ? 'text-neutral-600' : 'text-purple-400'
                    }`}
                  />
                </div>
                <h3 
                  className={`text-xl md:text-2xl font-light mb-4 transition-all duration-500 ${
                    hoveredFeature === index 
                      ? isDark ? 'text-black translate-x-2' : 'text-white translate-x-2'
                      : isDark ? 'text-white' : 'text-gray-800'
                  }`}
                >
                  {feature.title}
                </h3>
                <p 
                  className={`text-sm md:text-base leading-relaxed transition-colors duration-500 ${
                    hoveredFeature === index 
                      ? isDark ? 'text-neutral-600' : 'text-white/80'
                      : isDark ? 'text-neutral-500' : 'text-gray-600'
                  }`}
                >
                  {feature.description}
                </p>
                
                {/* Learn More */}
                <div 
                  className={`mt-8 flex items-center gap-2 text-xs tracking-wider uppercase transition-all duration-500 ${
                    hoveredFeature === index 
                      ? isDark ? 'opacity-100 translate-x-0 text-black' : 'opacity-100 translate-x-0 text-white'
                      : 'opacity-0 -translate-x-4'
                  }`}
                >
                  <span>Learn More</span>
                  <span>→</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Philosophy Quote */}
        <div
          className={`mt-24 lg:mt-32 text-center transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{ transitionDelay: '800ms' }}
        >
          <blockquote 
            className={`text-xl md:text-3xl lg:text-4xl font-extralight max-w-4xl mx-auto leading-relaxed ${
              isDark ? 'text-neutral-600' : 'text-gray-400'
            }`}
            style={{
              transform: `translateY(${mousePos.y * -15}px)`,
              transition: 'transform 0.5s ease-out',
            }}
          >
            &ldquo;Every child can learn, just not on the same day,
            <span className={isDark ? 'text-white' : 'text-purple-600'}> or in the same way.</span>&rdquo;
          </blockquote>
          <cite className={`block mt-8 text-[10px] tracking-[0.4em] uppercase not-italic ${
            isDark ? 'text-neutral-700' : 'text-gray-400'
          }`}>
            — George Evans
          </cite>
        </div>
      </div>
    </section>
  );
}