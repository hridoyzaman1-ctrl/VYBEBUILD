'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { ChevronDown, ArrowRight } from 'lucide-react';
import { useTheme } from 'next-themes';

export function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [rotation, setRotation] = useState(0);
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Continuous rotation animation - runs independently of mouse
  useEffect(() => {
    let animationId: number;
    let lastTime = performance.now();
    
    const animate = (currentTime: number) => {
      const delta = (currentTime - lastTime) / 1000;
      lastTime = currentTime;
      setRotation(prev => prev + delta * 10);
      animationId = requestAnimationFrame(animate);
    };
    
    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left - rect.width / 2) / rect.width,
      y: (e.clientY - rect.top - rect.height / 2) / rect.height,
    });
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [handleMouseMove]);

  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  const isDark = mounted && resolvedTheme === 'dark';

  return (
    <section
      ref={containerRef}
      className={`relative min-h-screen flex items-center justify-center overflow-hidden ${
        isDark ? 'bg-black' : 'bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50'
      }`}
    >
      {/* Animated Grid Background */}
      <div
        className={`absolute inset-0 ${isDark ? 'opacity-[0.03]' : 'opacity-[0.4]'}`}
        style={{
          backgroundImage: isDark 
            ? `linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)`
            : `linear-gradient(rgba(147,112,219,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(147,112,219,0.15) 1px, transparent 1px)`,
          backgroundSize: '100px 100px',
          transform: `translate(${mousePos.x * 30}px, ${mousePos.y * 30}px)`,
          transition: 'transform 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      />

      {/* Light Mode Decorative Blobs */}
      {!isDark && mounted && (
        <>
          <div 
            className="absolute top-20 right-20 w-96 h-96 bg-gradient-to-br from-purple-200/40 to-pink-200/40 rounded-full blur-3xl animate-blob"
            style={{
              transform: `translate(${mousePos.x * -60}px, ${mousePos.y * -60}px)`,
              transition: 'transform 0.8s ease-out',
            }}
          />
          <div 
            className="absolute bottom-40 left-20 w-80 h-80 bg-gradient-to-br from-blue-200/40 to-cyan-200/40 rounded-full blur-3xl animate-blob"
            style={{
              animationDelay: '-2s',
              transform: `translate(${mousePos.x * 50}px, ${mousePos.y * 50}px)`,
              transition: 'transform 0.8s ease-out',
            }}
          />
          <div 
            className="absolute top-1/2 left-1/3 w-64 h-64 bg-gradient-to-br from-pink-200/30 to-orange-200/30 rounded-full blur-3xl animate-blob"
            style={{
              animationDelay: '-4s',
              transform: `translate(${mousePos.x * 40}px, ${mousePos.y * 40}px)`,
              transition: 'transform 0.8s ease-out',
            }}
          />
        </>
      )}

      {/* Geometric Elements - Continuous Animation + Mouse Reactive */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Large Circle - Outer */}
        <div
          className="absolute w-[700px] h-[700px] rounded-full"
          style={{
            top: '50%',
            left: '50%',
            border: isDark 
              ? '2px solid rgba(255,255,255,0.18)' 
              : '2px solid rgba(147,112,219,0.25)',
            boxShadow: isDark 
              ? '0 0 80px rgba(255,255,255,0.05), inset 0 0 60px rgba(255,255,255,0.02)'
              : '0 0 80px rgba(147,112,219,0.15), inset 0 0 60px rgba(147,112,219,0.05)',
            transform: `translate(-50%, -50%) translate(${mousePos.x * -50}px, ${mousePos.y * -50}px) rotate(${rotation}deg)`,
          }}
        >
          {/* Orbiting dots on outer circle */}
          {[0, 60, 120, 180, 240, 300].map((angle, i) => (
            <div
              key={`outer-dot-${i}`}
              className={`absolute w-2.5 h-2.5 rounded-full ${isDark ? 'bg-white/50' : 'bg-purple-400/60'}`}
              style={{
                top: '50%',
                left: '50%',
                transform: `translate(-50%, -50%) rotate(${angle}deg) translateX(350px)`,
                boxShadow: isDark 
                  ? '0 0 15px rgba(255,255,255,0.6)'
                  : '0 0 15px rgba(147,112,219,0.6)',
              }}
            />
          ))}
        </div>
        
        {/* Medium Circle with reverse rotation */}
        <div
          className="absolute w-[450px] h-[450px] rounded-full"
          style={{
            top: '50%',
            left: '50%',
            border: isDark 
              ? '2px solid rgba(255,255,255,0.25)' 
              : '2px solid rgba(236,72,153,0.25)',
            boxShadow: isDark 
              ? '0 0 60px rgba(255,255,255,0.06), inset 0 0 40px rgba(255,255,255,0.03)'
              : '0 0 60px rgba(236,72,153,0.15), inset 0 0 40px rgba(236,72,153,0.05)',
            transform: `translate(-50%, -50%) translate(${mousePos.x * -70}px, ${mousePos.y * -70}px) rotate(${-rotation * 1.5}deg)`,
          }}
        >
          {/* Orbiting dots on medium circle */}
          {[0, 90, 180, 270].map((angle, i) => (
            <div
              key={`mid-dot-${i}`}
              className={`absolute w-2 h-2 rounded-full ${isDark ? 'bg-white/60' : 'bg-pink-400/60'}`}
              style={{
                top: '50%',
                left: '50%',
                transform: `translate(-50%, -50%) rotate(${angle}deg) translateX(225px)`,
                boxShadow: isDark 
                  ? '0 0 12px rgba(255,255,255,0.7)'
                  : '0 0 12px rgba(236,72,153,0.6)',
              }}
            />
          ))}
        </div>

        {/* Rotating Square - subtle */}
        <div
          className="absolute w-[350px] h-[350px]"
          style={{
            top: '50%',
            left: '50%',
            border: isDark 
              ? '1px solid rgba(255,255,255,0.06)' 
              : '1px solid rgba(147,112,219,0.15)',
            transform: `translate(-50%, -50%) translate(${mousePos.x * -40}px, ${mousePos.y * -40}px) rotate(${45 + rotation * 0.5}deg)`,
          }}
        />

        {/* Corner Lines with parallax */}
        <div 
          className={`absolute top-24 left-24 w-40 h-px ${isDark ? 'bg-white/10' : 'bg-purple-300/30'}`}
          style={{ 
            transform: `translateX(${mousePos.x * 25}px) scaleX(${isLoaded ? 1 : 0})`,
            transition: 'transform 0.5s ease-out, scale 1s ease-out',
            transformOrigin: 'left',
          }}
        />
        <div 
          className={`absolute top-24 left-24 w-px h-40 ${isDark ? 'bg-white/10' : 'bg-purple-300/30'}`}
          style={{ 
            transform: `translateY(${mousePos.y * 25}px) scaleY(${isLoaded ? 1 : 0})`,
            transition: 'transform 0.5s ease-out, scale 1s ease-out',
            transformOrigin: 'top',
          }}
        />
        <div 
          className={`absolute bottom-24 right-24 w-40 h-px ${isDark ? 'bg-white/10' : 'bg-pink-300/30'}`}
          style={{ 
            transform: `translateX(${mousePos.x * -25}px) scaleX(${isLoaded ? 1 : 0})`,
            transition: 'transform 0.5s ease-out, scale 1s ease-out 0.2s',
            transformOrigin: 'right',
          }}
        />
        <div 
          className={`absolute bottom-24 right-24 w-px h-40 ${isDark ? 'bg-white/10' : 'bg-pink-300/30'}`}
          style={{ 
            transform: `translateY(${mousePos.y * -25}px) scaleY(${isLoaded ? 1 : 0})`,
            transition: 'transform 0.5s ease-out, scale 1s ease-out 0.2s',
            transformOrigin: 'bottom',
          }}
        />

        {/* Floating Dots with different depths */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className={`absolute rounded-full ${isDark ? 'bg-white/20' : 'bg-purple-400/30'}`}
            style={{
              width: `${2 + (i % 3)}px`,
              height: `${2 + (i % 3)}px`,
              top: `${15 + (i * 7) % 70}%`,
              left: `${8 + (i * 13) % 84}%`,
              transform: `translate(${mousePos.x * (20 + i * 8)}px, ${mousePos.y * (20 + i * 8)}px)`,
              transition: `transform ${0.3 + i * 0.08}s cubic-bezier(0.16, 1, 0.3, 1)`,
              opacity: isLoaded ? 0.3 + (i % 3) * 0.2 : 0,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen pt-20 pb-20">
        {/* Main Heading */}
        <div className="text-center mb-8">
          {/* Tagline */}
          <div
            className={`mb-8 transition-all duration-1000 ${
              isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            <span className={`inline-flex items-center gap-4 text-[10px] md:text-xs tracking-[0.4em] uppercase ${
              isDark ? 'text-neutral-500' : 'text-purple-500'
            }`}>
              <span className={`w-10 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
              Aim High, Achieve Infinity
              <span className={`w-10 h-px ${isDark ? 'bg-white/20' : 'bg-purple-300'}`} />
            </span>
          </div>

          {/* Main Title */}
          <h1
            className={`transition-all duration-1000 ${
              isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '400ms' }}
          >
            <span 
              className={`block text-[clamp(2.5rem,10vw,8rem)] font-extralight tracking-[-0.02em] leading-[0.9] ${
                isDark ? 'text-white' : 'text-gray-800'
              }`}
              style={{
                transform: `translateX(${mousePos.x * -10}px)`,
                transition: 'transform 0.5s ease-out',
              }}
            >
              AIM CENTRE
            </span>
            <span 
              className="block text-[clamp(2.5rem,10vw,8rem)] font-extralight tracking-[-0.02em] leading-[0.9] text-transparent"
              style={{
                WebkitTextStroke: isDark ? '1px rgba(255,255,255,0.3)' : '2px rgba(147,112,219,0.5)',
                transform: `translateX(${mousePos.x * 10}px)`,
                transition: 'transform 0.5s ease-out',
              }}
            >
              360
            </span>
          </h1>

          {/* Subtitle */}
          <p
            className={`mt-12 md:mt-16 text-sm md:text-base font-light max-w-2xl mx-auto leading-[1.8] transition-all duration-1000 ${
              isDark ? 'text-neutral-500' : 'text-gray-600'
            } ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
            style={{ transitionDelay: '600ms' }}
          >
            A revolutionary e-learning platform delivering comprehensive education
            in English & Bangla, with specialized programs for children with special needs
            and integrated mental health support.
          </p>

          {/* CTA Buttons */}
          <div
            className={`mt-14 flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-1000 ${
              isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '800ms' }}
          >
            <button
              onClick={scrollToAbout}
              className={`group relative px-10 py-4 text-xs tracking-[0.2em] uppercase overflow-hidden transition-all duration-500 ${
                isDark 
                  ? 'bg-white text-black hover:bg-neutral-200' 
                  : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg shadow-purple-500/25 rounded-full'
              }`}
            >
              <span className="relative z-10 flex items-center gap-3">
                Explore Programs
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
            </button>
            <button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className={`group px-10 py-4 border text-xs tracking-[0.2em] uppercase transition-all duration-500 ${
                isDark 
                  ? 'border-white/20 text-white hover:border-white/50 hover:bg-white/5' 
                  : 'border-purple-300 text-purple-600 hover:border-purple-500 hover:bg-purple-50 rounded-full'
              }`}
            >
              Get Started
            </button>
          </div>

          {/* Stats Row */}
          <div
            className={`mt-24 md:mt-32 grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-16 transition-all duration-1000 ${
              isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '1000ms' }}
          >
            {[
              { value: '50K+', label: 'Active Learners' },
              { value: '200+', label: 'Expert Courses' },
              { value: '98%', label: 'Success Rate' },
              { value: '24/7', label: 'Support' },
            ].map((stat, index) => (
              <div key={index} className="text-center group cursor-default">
                <div 
                  className={`text-2xl md:text-3xl font-extralight tracking-tight transition-all duration-500 ${
                    isDark ? 'text-white group-hover:text-white/70' : 'text-gray-800 group-hover:text-purple-600'
                  }`}
                  style={{
                    transform: `translateY(${mousePos.y * (5 + index * 2)}px)`,
                    transition: 'transform 0.4s ease-out, color 0.3s',
                  }}
                >
                  {stat.value}
                </div>
                <div className={`text-[9px] md:text-[10px] tracking-[0.2em] uppercase mt-2 ${
                  isDark ? 'text-neutral-600' : 'text-gray-500'
                }`}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div
        className={`absolute bottom-12 left-1/2 -translate-x-1/2 transition-all duration-1000 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        style={{ transitionDelay: '1400ms' }}
      >
        <button
          onClick={scrollToAbout}
          className={`flex flex-col items-center gap-4 transition-colors duration-500 group ${
            isDark ? 'text-neutral-600 hover:text-white' : 'text-purple-400 hover:text-purple-600'
          }`}
        >
          <span className="text-[9px] tracking-[0.4em] uppercase">Scroll</span>
          <div className={`w-px h-16 relative overflow-hidden ${isDark ? 'bg-white/10' : 'bg-purple-200'}`}>
            <div className={`absolute top-0 left-0 w-full h-[30%] animate-scroll-line ${isDark ? 'bg-white/50' : 'bg-purple-500'}`} />
          </div>
          <ChevronDown className="w-3 h-3 animate-bounce" />
        </button>
      </div>
    </section>
  );
}