'use client';

import {
  Navigation,
  HeroSection,
  AboutSection,
  ProgramsSection,
  ServicesSection,
  ApproachSection,
  TestimonialsSection,
  ContactSection,
  Footer,
  ParticleField,
} from '@/components/landing';

export default function HomePage() {
  return (
    <main className="relative min-h-screen">
      {/* Noise Overlay */}
      <div className="noise-overlay" />
      
      {/* 3D Particle Background */}
      <ParticleField />

      {/* Navigation */}
      <Navigation />

      {/* Page Sections */}
      <HeroSection />
      <AboutSection />
      <ProgramsSection />
      <ServicesSection />
      <ApproachSection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
    </main>
  );
}
