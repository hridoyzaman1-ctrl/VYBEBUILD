# AIM Centre 360 - E-Learning Platform

## High-level Strategy and Goal

AIM Centre 360 is an innovative e-learning EdTech platform with the tagline "Aim High, Achieve Infinity". The platform provides comprehensive education services including:

- **English Medium Education** - Cambridge & Edexcel curriculum
- **Bangla Version** - National Curriculum Bangladesh
- **Special Needs Education** - Customized programs for autism, ADHD, dyslexia
- **Mental Health & Counselling** - Student wellness programs
- **Skill Development** - Future-ready skills training
- **Test Preparation** - IELTS, SAT, GRE preparation

The website design is inspired by the ETH Zurich Space website with a sophisticated, minimal aesthetic featuring deep black backgrounds, clean white typography, and elegant animations.

## Changes Implemented

### Design System
- **Color Palette**: Pure monochromatic - black (#000, #050505, #0a0a0a) backgrounds with white text and neutral grays
- **Typography**: Inter (primary) + JetBrains Mono (monospace) fonts
- **Visual Style**: Minimalist with geometric shapes, subtle grid patterns, clean borders

### Landing Page Sections (Refactored)

1. **Navigation** (`src/components/landing/Navigation.tsx`)
   - Fixed header with scroll-triggered background blur
   - Active section highlighting
   - Mobile responsive hamburger menu
   - Light/dark mode toggle

2. **Hero Section** (`src/components/landing/HeroSection.tsx`)
   - Mouse-reactive parallax geometric circles
   - Orbiting particles on scroll
   - Large typography with text-stroke effect
   - Stats row with hover interactions
   - Animated scroll indicator

3. **Particle Field** (`src/components/landing/ParticleField.tsx`)
   - Canvas-based 3D particle system
   - Mouse-reactive parallax depth
   - Particle connections within proximity
   - Smooth animation loop

4. **About Section** (`src/components/landing/AboutSection.tsx`)
   - Scroll-triggered reveal animations
   - Feature grid with hover color inversion
   - Highlights bar with hover effects
   - Inspirational quote with parallax

5. **Programs Section** (`src/components/landing/ProgramsSection.tsx`)
   - 6 comprehensive programs
   - Interactive list with horizontal fill animation on hover
   - Detailed program info panel
   - Meta badges (duration, students, rating)

6. **Services Section** (`src/components/landing/ServicesSection.tsx`)
   - 8 platform features in grid layout
   - Vertical fill animation on hover
   - Icon animations
   - CTA button

7. **Approach Section** (`src/components/landing/ApproachSection.tsx`)
   - "The AIM Method" 5-step framework
   - Step navigation buttons
   - Animated geometric visual with orbiting dots
   - Progress indicator
   - Feature stats grid

8. **Testimonials Section** (`src/components/landing/TestimonialsSection.tsx`)
   - Auto-advancing carousel (6s interval)
   - Navigation controls (prev/next buttons)
   - Progress indicators
   - Stats grid with hover effects

9. **Contact Section** (`src/components/landing/ContactSection.tsx`)
   - Form with validation
   - Contact info cards with hover animations
   - Free consultation box
   - Toast notifications

10. **Footer** (`src/components/landing/Footer.tsx`)
    - Newsletter subscription
    - Multi-column navigation links
    - Social media links with hover effects
    - Scroll-to-top button

### Interactive Features
- Mouse-tracking parallax effects throughout all sections
- Scroll-triggered animations and reveals
- Smooth scroll navigation between sections
- Hover state transitions with color inversion
- Rotating/orbiting geometric elements
- Canvas-based particle background

## Architecture and Technical Decisions

### Component Structure
All landing page components are organized in `src/components/landing/` with an `index.ts` barrel file for clean imports.

### Animation Approach
- Uses native CSS transitions with `cubic-bezier(0.16, 1, 0.3, 1)` easing
- React state for scroll position and mouse tracking
- `useCallback` for optimized event handlers
- `passive: true` on scroll listeners for performance

### Styling Strategy
- Tailwind CSS for utility-first styling
- CSS custom properties for theme colors
- Hardcoded color values (black/white/neutral) for consistent dark aesthetic
- No gradients - pure monochromatic palette

### Performance Considerations
- Canvas-based particle system for smooth background animation
- Intersection Observer for lazy reveal animations
- Passive event listeners where appropriate
- CSS transforms for GPU-accelerated animations
